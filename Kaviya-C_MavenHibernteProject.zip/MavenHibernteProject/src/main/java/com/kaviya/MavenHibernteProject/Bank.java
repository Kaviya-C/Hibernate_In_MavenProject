package com.kaviya.MavenHibernteProject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Bank_Details")
public class Bank 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Bank_Id")
	private int bankId;

	@Column(name = "Bank_name", length = 15, nullable = false)
	private String bankName;
	@Column(name = "Bank_Address", nullable = false, length = 25)
	private String bankAddress;

	public void setBankId(int bankId) {
		this.bankId = bankId;
	}

	public int getBankId() {
		return bankId;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankAddress(String bankAddress) {
		this.bankAddress = bankAddress;
	}

	public String getBankAddress() {
		return bankAddress;
	}

}
